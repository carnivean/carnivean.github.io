/**
 * Created by Erik Kynast on 12.04.2017.
 */
public interface Resizable {
    public void resize(double factor);
}
