/**
 * Created by Erik Kynast on 11.04.2017.
 */
public interface LiquidFuel {
    int getRange();
    int getEmissionTier();
}
